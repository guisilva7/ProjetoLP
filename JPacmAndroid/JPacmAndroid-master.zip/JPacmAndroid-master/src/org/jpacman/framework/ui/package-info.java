/**
  * This package contains classes for building the (Swing)
  * user interface of the JPacman game.
  * 
  * @author Arie van Deursen, January 2012.
  */
package org.jpacman.framework.ui;
