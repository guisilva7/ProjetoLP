import org.jpacman.framework.view.Animator;
import org.junit.Test;


public class AnimatorTest {
	
	@Test
	public void testAnimator() throws InterruptedException{
		//Animator a = new Animator(null);
		
	}
}
